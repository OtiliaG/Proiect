package Banca;

import java.util.Scanner;

public class MainBanca {
    public static void main(String[] args) {
        ClientBanca client1 = new ClientBanca("Birsan", "Jullia");
        client1.setUsername("test");
        client1.setPassword("1234");

        ContCurent contCurent1 = new ContCurent("RO176777637373", "RON");
        ContEconomii contEconomii = new ContEconomii("RO16789263663", "RON");
        client1.adaugaContInLista(contCurent1);
        client1.adaugaContInLista(contEconomii);

        //transfer
        ContCurent contCurent2 = new ContCurent("RO477556556573", "RON");


        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("Cum vrei sa interactionezi cu banca? 1 - ATM, 2 - APP, 3 - EXIT");
            int optiune = scanner.nextInt();

            if (optiune == 1) {
                ATM atm = new ATMImplementare();
                System.out.println("Alege operatiunea dorita");
                System.out.println("1-DEPUNERE");
                System.out.println("2-RETRAGERE");
                System.out.println("3-INTEROGARE SOLD");

                int optiuneAtm = scanner.nextInt();
                switch (optiuneAtm) {
                    case 1:
                        System.out.println("Suma depunere? ");
                        double sumaDepunere = scanner.nextDouble();
                        atm.depunere(sumaDepunere, contCurent1);
                        break;
                    case 2:
                        System.out.println("Suma retragere? ");
                        double sumaRetragere = scanner.nextDouble();
                        try {
                            atm.retragere(sumaRetragere, contCurent1);
                        }catch (SoldException e){
                            System.out.println(e.getMessage());
                        }
                        break;
                    case 3:
                        atm.interogareSold(contCurent1);
                        break;

                    default:
                        System.out.println("Optiune invalida");
                }

            } else if (optiune == 2) {
                AplicatieBancara aplicatieBancara = new AplicatieBancaraImpl();
                aplicatieBancara.adaugaClient(client1.getUsername(), client1.getPassword());
                System.out.println("Introdu username");
                String username = scanner.next();
                System.out.println("Introdu password");
                String password = scanner.next();
                if (aplicatieBancara.verificaCredentiale(username, password)) {
                    System.out.println("Alege operatiunea dorita");
                    System.out.println("1-Transfer");
                    System.out.println("2-Citire sold");
                    int optiuneApp = scanner.nextInt();
                    switch (optiuneApp) {
                        case 1:
                            System.out.println("Introdu suma pentru transfer");
                            double sumaTransfer = scanner.nextDouble();
                            aplicatieBancara.transfer(contCurent1, contCurent2, sumaTransfer);
                            break;
                        case 2:
                            aplicatieBancara.citireSold(contCurent1);
                            break;
                        default:
                            System.out.println("Optiunea aleasa este invalida");
                    }
                } else {
                    System.out.println("Username-ul sau parola nu sunt corecte");
                }

            } else if (optiune == 3) {
                running = false;
            }
        }
    }
}
