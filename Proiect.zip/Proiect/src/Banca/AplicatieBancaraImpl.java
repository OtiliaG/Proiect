package Banca;

import java.util.HashMap;
import java.util.Map;

public class AplicatieBancaraImpl implements AplicatieBancara {

    public static Map<String, String> utilizatori = new HashMap<>();


    @Override
    public void transfer(ContCurent cont1, ContCurent cont2, double suma) {
        try {
            cont1.transfer(suma, cont2);

        }catch (SoldException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void citireSold(Cont cont) {
        System.out.println("Ai in cont: " + cont.getSold());

    }

    @Override
    public void adaugaClient(String username, String password) {
        utilizatori.put(username, password);
    }

    @Override
    public boolean verificaCredentiale(String username, String password) {
        for (Map.Entry<String, String> entry : utilizatori.entrySet()) {
            if (entry.getKey().equals(username) && (entry.getValue().equals(password))) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}