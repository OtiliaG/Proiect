package Banca;

public class ContEconomii extends Cont{
    final double dobanda = 0.05;
    final int termen = 12;
    private int luniDeschis = 0;
    private final double cuantum = 50;

    public ContEconomii(String iban, String valuta){
        super (iban, 0, valuta);
    }
    @Override
    public void depunere(double suma) {
        double sumaFinala = suma + suma * dobanda;
        super.setSold(sumaFinala);
    }

    @Override
    public void retragere(double suma) {
        double sumaDeRetras = super.getSold()*cuantum/100;
        if ((luniDeschis == termen)&& sumaDeRetras <= suma){
            double sumaFinala = super.getSold() - suma;
            super.setSold(sumaFinala);
        }else{
            System.out.println("Nu poti retrage acum bani");

        }
    }

    public void incrementeazaLuni(){
        this.luniDeschis++;
    }
}
