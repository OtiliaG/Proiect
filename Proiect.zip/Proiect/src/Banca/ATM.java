package Banca;

public interface ATM {
    void retragere(double suma, Cont cont) throws SoldException;
    void depunere (double suma, Cont cont);
    void interogareSold(Cont cont);
}
