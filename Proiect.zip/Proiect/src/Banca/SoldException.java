package Banca;

public class SoldException extends Exception{
    public SoldException (String mesaj){
        super(mesaj);
    }
}
