package Banca;

public interface AplicatieBancara {
    void transfer (ContCurent cont1, ContCurent cont2, double suma);
    void citireSold (Cont cont);
    void adaugaClient (String username, String password);
    boolean verificaCredentiale (String username, String password);
}
