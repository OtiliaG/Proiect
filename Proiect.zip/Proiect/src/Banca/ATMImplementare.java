package Banca;

public class ATMImplementare implements ATM{

    @Override
    public void retragere(double suma, Cont cont) throws SoldException {
        cont.retragere(suma);

    }

    @Override
    public void depunere(double suma, Cont cont) {
        cont.depunere(suma);

    }

    @Override
    public void interogareSold(Cont cont) {
        System.out.println("Ai in cont " + cont.getSold());

    }
}
