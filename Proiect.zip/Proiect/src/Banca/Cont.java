package Banca;

public abstract class Cont {
    private String valuta;
    private double sold;
    private String iban;

    public Cont (String iban, double sold, String valuta){
        this.iban = iban;
        this.sold = sold;
        this.valuta = valuta;
    }

    public abstract void depunere(double suma);
    public abstract void retragere(double suma) throws SoldException;

    public double getSold(){
        return sold;
    }

    public void setSold(double sold){
        this.sold = sold;
    }

}
