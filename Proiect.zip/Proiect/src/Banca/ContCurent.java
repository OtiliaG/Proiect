package Banca;

public class ContCurent extends Cont {

    private final double comision = 10;

    public ContCurent(String iban, String valuta) {
        super(iban, 0, valuta);
    }

    @Override
    public void depunere(double suma) {
        double sumaFinala = super.getSold() + suma;
        super.setSold(sumaFinala);

    }

    @Override
    public void retragere(double suma) throws SoldException {
        if (super.getSold() < suma) {
            throw new SoldException("Nu ai suficienti bani in cont");
        } else {
            double sumaFinala = super.getSold() - suma;
            super.setSold(sumaFinala);
        }
    }

    public void transfer(double suma, ContCurent contCurent)throws SoldException{
        double sumaFinalaDeTransfer = suma + suma * comision / 100;
        if (super.getSold() < sumaFinalaDeTransfer) {
            throw new SoldException("Nu ai suficienti bani in cont");
        } else {
            super.setSold(super.getSold()- sumaFinalaDeTransfer);
            contCurent.setSold(suma);
        }
    }
}